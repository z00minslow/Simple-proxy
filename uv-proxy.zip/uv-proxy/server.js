import { createServer } from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { server as wisp } from "@mercuryworkshop/wisp-js/server";
import { uvPath } from "@titaniumnetwork-dev/ultraviolet";

const PORT = process.env.PORT || 8080;
const root = path.dirname(fileURLToPath(import.meta.url));

// Find a package's static files by looking for a known file inside it.
// This avoids depending on which helper exports a given package version has.
function findPkgDir(pkg, marker, required = true) {
  const base = path.join(root, "node_modules", pkg);
  const candidates = [base, path.join(base, "dist"), path.join(base, "lib")];
  for (const dir of candidates) {
    if (fs.existsSync(path.join(dir, marker))) return dir;
  }
  if (!required) return null;
  console.error(`\nCould not find "${marker}" for ${pkg}.`);
  for (const dir of candidates) {
    if (fs.existsSync(dir)) console.error(`  ${dir}:`, fs.readdirSync(dir).join(", "));
  }
  console.error("Paste this output back to Claude so it can fix the paths.\n");
  process.exit(1);
}

const epoxyDir = findPkgDir("@mercuryworkshop/epoxy-transport", "index.mjs", false);
const libcurlDir = findPkgDir("@mercuryworkshop/libcurl-transport", "index.mjs");
const baremuxDir = findPkgDir("@mercuryworkshop/bare-mux", "worker.js");

const app = express();

app.use(express.static(path.join(root, "public")));
app.use("/uv/", express.static(uvPath));
if (epoxyDir) app.use("/epoxy/", express.static(epoxyDir));
app.use("/libcurl/", express.static(libcurlDir));
app.use("/baremux/", express.static(baremuxDir));

const server = createServer(app);

// The proxy tunnels its traffic through a Wisp websocket.
server.on("upgrade", (req, socket, head) => {
  if (req.url.endsWith("/wisp/")) wisp.routeRequest(req, socket, head);
  else socket.end();
});

server.listen(PORT, () => {
  console.log(`Proxy running at http://localhost:${PORT}`);
});
